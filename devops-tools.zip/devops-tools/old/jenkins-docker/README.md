# Running Jenkins as Container

## 1. Description
This is the first aproach to run Jenkins as Container. I used CasC to configure Jenkins.

-  